using UnityEngine;
using System.Collections;

public class EnemyHealth : MonoBehaviour
{
    [Header("����")]
    public int maxHealth = 3;
    public int contactDamage = 2;
    public GameObject deathEffectPrefab;
    public float flashDuration = 0.1f;

    public Vector3 deathEffectOffset = new Vector3(0, 0.5f, 0);

    // ���� ���� Ȯ�ο� (AI�� ������ ��)
    public bool IsDead { get; private set; }

    int currentHealth;
    SpriteRenderer sr;
    Collider2D col; // �ݶ��̴� �����

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        col = GetComponent<Collider2D>(); // �ݶ��̴� ��������
        currentHealth = maxHealth;
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        if (currentHealth <= 0) Die();
        else StartCoroutine(FlashRoutine());
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (IsDead) return; // �׾����� ���� �� ��
        TryDamagePlayer(collision.gameObject);
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (IsDead) return;
        TryDamagePlayer(collision.gameObject);
    }

    void TryDamagePlayer(GameObject target)
    {
        if (target.CompareTag("Player"))
        {
            PlayerHealth playerHealth = target.GetComponent<PlayerHealth>();
            if (playerHealth != null)
            {
                playerHealth.TakeDamage(contactDamage, transform.position.x);
            }
        }
    }

    void Die()
    {
        IsDead = true;

        // ����Ʈ ����
        if (deathEffectPrefab)
        {
            Instantiate(deathEffectPrefab, transform.position + deathEffectOffset, Quaternion.identity);
        }

        // ����(Destroy) ��� �����
        sr.enabled = false;   // �׸� ����
        col.enabled = false;  // �浹 ����
    }

    // �ǻ츮�� �Լ� (AI�� ȣ��)
    public void Revive()
    {
        IsDead = false;
        currentHealth = maxHealth;

        sr.enabled = true;    // �׸� �ѱ�
        col.enabled = true;   // �浹 �ѱ�
        sr.color = Color.white; // ���� �ʱ�ȭ
    }

    IEnumerator FlashRoutine()
    {
        sr.color = new Color(1f, 0.5f, 0.5f, 1f);
        yield return new WaitForSeconds(flashDuration);
        sr.color = Color.white;
    }
}